Voila le puissance 4, ou plus, tout est variable via le petit menu 'Config'.
J'ai fait une petite IA, il est possible d'en mettre autant de joueurs qu'on veut. 
(on peut donc faire un puissance 8 sur une grille de 50 sur 50 ou se battent 3 IA)

Le code est fait en typescript (https://www.typescriptlang.org/), une surcouche de JS qui permet de rajouter des types, 
interfaces et une meilleure gestion des classes et objets.
il est de toute façon compilé en JS classique, mais le TS est en général plus simple a lire, 
et j'ai laissé les .maps pour le débug chrome.

Une version mise en ligne est aussi disponible a https://theolemoine.net/connect_howmanyever/ (au cas où)